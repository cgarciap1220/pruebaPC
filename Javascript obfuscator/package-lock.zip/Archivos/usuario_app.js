const usuarios = new Vue({
	el:'#usuariosForm',
	data: function () {
		return{
			url:dir,
			tipoUsuarios:[],
			departamentos:[],
			municipios:[],
			departamento:{
				idDepartamento:1
			},
			municipios:[],
			profesiones:[],
			menu: false,
			active: null,
			nuevoUsuario:{
				nombre:'',
				apellidos:'',
				email:'',
				contrasenia:'',
				repContrasenia:'',
				celular:'',
				telefono:'',
				fechaNac:'',
				direccion:'',
				direcEmp:'',
				municipio:'101',
				ocupacion:'',
				profesion:'1',
				tipoUsuario:'1',
				dpi:'',
				edad:'',
				genero:1,
				etnia:1,
				fotoPerfil:'',
				nit:''
			},
			usuarios:[],
			chooseUsuario:{},
			formValidate:[],
			successMSG:'',
			errorMSG:'',   
			valid:true,
			password: '',
			reppassword: '',
			email: '',
			mensajes: {
				email: [],
				password: [],
			},
			errors: false,
			emailRules: [
				v => !!v || 'Es requerido ingresar el email',
				v => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v) || 'El correo electrónico debe tener un formato válido'
			],
			show1: false,
			show2: false,
			rules: {
				required: value => !!value || 'Es requerido ingresar la contraseña.',
				PassMatch: () => (this.nuevoUsuario.contrasenia === this.nuevoUsuario.repContrasenia) || 'Las contraseñas no coinciden',
			},
			nameRules: [
				v => !!v || 'Es requerido ingresar el nombre'
			],
			edadRules:[
				v => /^(\s*|\d+)$/.test(v) || 'Debe ingresar solo números'
			],
			telefonoRules: [
				//v => /(\+502)?\s?\(?\d{3}\)?-?\s?\d{4}-\d{4}/.test(v) || 'El número de teléfono debe tener un formato válido'
				v => /^(\s*|\d+)$/.test(v) || 'Debe ingresar solo números',
				v => v.length <= 8 || 'El número de teléfono debe tener un formato válido'
			],
			dpiRules: [
				v => /^(\s*|\d+)$/.test(v) || 'Debe ingresar solo números',
				v => v.length <= 13 || 'El número de DPI debe tener un formato válido'
			],
			genero:[
				{
					opcion:'Femenino',
					value:1
				},
				{
					opcion:'Masculino',
					value:2
				}
			],
			etnias:[
				{
					opcion:'Ladino',
					value:1
				},
				{
					opcion:'Maya',
					value:2
				},
				{
					opcion:'Garífuna',
					value:3
				}
			],
			nuevaFoto: false
		}
	},
	watch: {
		menu (val) {
			val && setTimeout(() => (this.$refs.picker.activePicker = 'Year'))
		}
	},
	created(){
		this.mostrarPerfil();
		this.getDepartamentos();
		this.getProfesiones();
		this.getMunicipios();
		this.getMunicipiosDpto();
	},
	methods:{
		saveUp (date) {
			this.$refs.menu[0].save(date);
			this.chooseUsuario.edad = this.diff_years(new Date(), new Date(this.chooseUsuario.fechaNac))
		},
		saveIns (date) {
			this.$refs.menu.save(date);
			this.nuevoUsuario.edad = this.diff_years(new Date(), new Date(this.chooseUsuario.fechaNac))
		},
		diff_years(dt2, dt1) {
			var diff =(dt2.getTime() - dt1.getTime()) / 1000;
			diff /= (60 * 60 * 24);
			return Math.abs(Math.round(diff/365.25));
		},
		validarEmail(){
			var mail = this.nuevoUsuario.email;
			var self = this;
			axios.post(this.url+"Usuario_controller/validarEmail", {
				params: {
					email: mail
				}
			})
				.then(function (response) {
					self.msgUsuarioExiste = response.data.msg;
					self.errorUsuarioExiste = response.data.error;
				})
				.catch(function (error) {
					console.log("error");

				});
				this.mensajes.email=this.errorUsuarioExiste?[this.msgUsuarioExiste]:[];
				this.$refs["mail"].validate();
				return true;
		},
		submitForm(){
			var self = this;

			self.nuevoUsuario.fotoPerfil = $('#foto').prop('files')[0];
			if(this.$refs.form.validate()) {
					var formData = self.formData(self.nuevoUsuario);
					//formData.append("fotoPerfil",$('#foto').prop('files')[0]);

					axios.post(this.url+"Usuario_controller/agregarUsuario", formData).then(function(response){
						if(response.data.error || response.data.error == "undefined"){
							//this.validateForm = response.data.msg;
							self.errorMSG = response.data.msg;
							swal({
								//title: "Agregar Usuaio",
								text: self.errorMSG,
								icon: "error",
								buttons: false,
								timer: 3000
							});
						}else{
							self.successMSG = response.data.msg;
							//self.successMSG = response.data.msgSuccess;
								swal({
									//title: "Agregar Usuaio",
									text: self.successMSG,
									icon: "success",
									buttons: false,
									timer: 3000
								})
									.then(() => {
										window.location.href = self.url;
									});

							/*console.log(response.data);
							self.clearAll();
							self.clearMSG();
							window.location.href = self.url;*/
						}
					})
				}
		},
		mostrarPerfil(){
			var self = this;
			axios.get(self.url+"Usuario_controller/mostrarDatosPerfil").then(function(response){
				if(response.data.usuarios != null){
					response.data.usuarios[0].genero = parseInt(response.data.usuarios[0].genero);
					response.data.usuarios[0].etnia = parseInt(response.data.usuarios[0].etnia);
					if (response.data.usuarios[0].fechaNac == null)
						response.data.usuarios[0].fechaNac = "";
					else
						response.data.usuarios[0].edad = self.diff_years(new Date(), new Date(response.data.usuarios[0].fechaNac))
					if (response.data.usuarios[0].dpi == 0)
						response.data.usuarios[0].dpi = "";
					self.usuarios = response.data.usuarios;

					for( var i in self.usuarios){
						self.chooseUsuario = self.usuarios[i];
						self.departamento.idDepartamento = self.usuarios[i].idDepartamento;
					}
					self.getMunicipiosDpto();



				}
			})

		},

		login() {
			var self = this;
			this.mensajes.email = [];
			this.mensajes.pass = [];
			//	if(this.$refs.form.validate()) {
			var formData = this.formData(this.nuevoUsuario);
			axios.post(this.url + "Usuario_controller/login", formData).then(function (response) {


				if (response.data.error) {
					self.msgUsuarioExiste= response.data.msg;
					if(response.data.tipoError == 'p'){
						self.mensajes.password.push(self.msgUsuarioExiste);
						self.errors=true;
					}
					if (response.data.tipoError == 'u'){
						self.mensajes.email.push(self.msgUsuarioExiste);
						self.errors=true;
					}
					self.$refs['form'].resetValidation();
				} else {
					self.successMSG = response.data.msg;

						swal({
							//title: "Login",
							text: self.successMSG,
							icon: "success",
							buttons: false,
							timer: 2000
						})
							.then(() => {
								if(response.data.tipoUsuario == 0)
								{
									window.location.href = self.url+"Empresa_controller/empresaCategoria?t=1";
								}
								else{
									window.location.href = self.url;
								}
						});

						
						
				}
			})

			//}
		},

		mostrarUsuarios(){
			var self = this;
			axios.get(this.url+"Usuario_controller/obtener_usuarios").then(function(response){
				if(response.data.usuarios == null){
					self.noResult();
				}else{
					self.getData(response.data.usuarios);


				}
			})
		},

		searchUsuario(){
			var self = this;
			var formData = self.formData(self.search);
			axios.post(this.url+"Usuario_controller/buscar_usuario", formData).then(function(response){
				if(response.data.usuarios == null){
					self.noResult()

				}else{
					self.getData(response.data.usuarios);

				}
			})
		},


		modificarUsuario(){
			var self = this;
			if (self.nuevaFoto == true) {
				self.chooseUsuario.fotoPerfil = $('#foto').prop('files')[0]
			}

			this.chooseUsuario['idDepartamento']= self.departamento['idDepartamento'];
			var formData = self.formData(this.chooseUsuario);
			axios.post(this.url+"Usuario_controller/actualizarUsuario", formData).then(function(response){

				if(response.data.error){
					//self.formValidate = response.data.msg;
					self.errorMSG = response.data.msg;
					swal({
						//title: "Agregar Usuaio",
						text: self.errorMSG,
						icon: "error",
						buttons: false,
						timer: 3000
					});
				}else{
					self.successMSG = response.data.msg;
					swal({
						//title: "Agregar Usuaio",
						text: self.successMSG,
						icon: "success",
						buttons: false,
						timer: 3000
					})
						.then(() => {

							self.clearAll();
							self.clearMSG();
							location.reload();
						});

				}
			})
		},
		getDepartamentos() {
			var self = this;
			axios.post(this.url + "Referencias_controller/obtenerDepartamento").then(function(response) {
				self.departamentos = response.data.departamentos;

			});
		},
		getMunicipios() {
			var self = this;
			axios.post(this.url + "Referencias_controller/obtenerMunicipios").then(function(response) {
				self.municipios = response.data.municipios;

			});
		},
		getMunicipiosDpto(){
			var self = this;
			var formData = self.formData(this.departamento);
			axios.post(this.url + "Referencias_controller/obtenerMunicipioDpto",formData).then(function(response) {
				self.municipios = response.data.municipios;


			});
		},
		getProfesiones(){
			var self = this;
			axios.post(this.url + "Referencias_controller/obtenerProfesion").then(function(response) {
				self.profesiones = response.data.profesiones;
			});
		},
		select(usuario){
			var self = this;
			self.chooseUsuario = usuario;

		},
		/*eliminarUsuario(){
			var self = this;
			var formData = self.formData(self.chooseUsuario);
			axios.post(this.url+"Usuario_controller/eliminar_usuarios", formData).then(function(response){
				if(!response.data.error){
					self.successMSG = response.data.msg;
					self.clearAll();
					self.clearMSG();

				}
			})
		},*/
		cambiarPass(){
			var self = this;
			var formData = self.formData(self.nuevoUsuario);
			axios.post(this.url+"Usuario_controller/actualizarContrasenia", formData).then(function(response){

				if(response.data.error){
					//self.formValidate = response.data.msg;
					self.errorMSG = response.data.msg;
					swal({

						text: self.errorMSG,
						icon: "error",
						buttons: false,
						timer: 3000
					});
				}else{
					self.successMSG = response.data.msg;
					swal({

						text: self.successMSG,
						icon: "success",
						buttons: false,
						timer: 3000
					})
						.then(() => {
							self.clearAll();
							self.clearMSG();
							window.location.href = self.url+'Usuario_controller/loginVista';
						});

				}



				/*if(response.data.error){
					self.formValidate = response.data.msg;
				}else{
					self.successMSG = response.data.success;
					self.clearAll();
					self.clearMSG();
					window.location.href = self.url+'Usuario_controller/loginVista';
				}*/
			})
		},

		formData(obj){
			var formData = new FormData();
			for ( var key in obj ) {
				formData.append(key, obj[key]);
			}
			return formData;
		},
		clearMSG(){
			var self = this;
			setTimeout(function(){
				self.successMSG=''
			},3000); // disappearing message success in 2 sec
		},
		clearAll(){
			var self = this;
			self.nuevoUsuario ={
				nombre:'',
				apellidos:'',
				email:'',
				contrasenia:'',
				repContrasenia:'',
				celular:'',
				telefono:'',
				fechaNac:'',
				direccion:'',
				direcEmp:'',
				municipio:'',
				ocupacion:'',
				profesion:'',
				tipoUsuario:'1'
			},
			self.active = null;
			departamento = {
				idDepartamento:''
			};

			self.refresh()

		},

		getData(usuarios){
			var self = this;
			self.emptyResult = false; // become false if has a record
			self.totalUsuarios = usuarios.length //get total of histroia
			self.usuarios = usuarios.slice(self.currentPage * self.rowCountPage, (self.currentPage * self.rowCountPage) + self.rowCountPage); //slice the result for pagination

			// if the record is empty, go back a page
			if(self.usuarios.length == 0 && self.currentPage > 0){
				self.pageUpdate(app.currentPage - 1)
				self.clearAll();
			}
		},
		noResult(){
			var self = this;
			self.emptyResult = true;  // become true if the record is empty, print 'No Record Found'
			self.usuarios = null
			self.totalUsuarios = 0 //remove current page if is empty

		},
		pageUpdate(pageNumber){
			var self = this;
			self.currentPage = pageNumber; //receive currentPage number came from pagination template
			self.refresh()
		},
		refresh(){
			var self = this;
			self.mostrarPerfil(); //for preventing

		},


	}
});
